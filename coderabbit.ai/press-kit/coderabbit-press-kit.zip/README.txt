CODERABBIT PRESS KIT
August 2026

CONTENTS
- coderabbit-primary-black.svg — primary logo for light backgrounds
- coderabbit-primary-black.png — transparent PNG of the primary black logo
- coderabbit-reverse-white.svg — white lockup using primary geometry
- coderabbit-reverse-white.png — transparent PNG of the reverse white logo
- coderabbit-orange-black.svg — black lockup using primary geometry
- coderabbit-mark-orange.svg — primary orange standalone mark
- coderabbit-mark-white.svg — reverse white standalone mark
- coderabbit-mark-white.png — transparent PNG of the white standalone mark
- coderabbit-mark-black.svg — black standalone mark
- coderabbit-mark-black.png — transparent PNG of the black standalone mark
- coderabbit-team.jpeg — CodeRabbit team photo
- coderabbit-founders-july-2026.jpg — CodeRabbit founders photo, July 2026
- coderabbit-change-stack.png — product shot: CodeRabbit Review and ChangeStack
- coderabbit-slack-agent.png — product shot: CodeRabbit Slack Agent
- coderabbit-plan.png — product shot: CodeRabbit Plan

ADDITIONAL ASSETS
For AI/EPS logo masters, product templates, or video assets not included in this package, contact pr@coderabbit.ai.

USAGE
Keep logo artwork intact and preserve its proportions. Use the black logo on
light surfaces and the white logo on dark surfaces. Do not recolor, redraw,
rotate, stretch, or add effects to approved artwork. CodeRabbit Orange is
#FF570A.

For approved clear-space, safe-area, scale, and visual-balance guidance, see
the CodeRabbit Brand Guidelines: https://www.coderabbit.ai/brand

PRESS CONTACT
pr@coderabbit.ai
